package active;
import java.sql.*;
public class DBConnection {
	public void getConnect()
	{
		try
		{
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
  			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/XE","payroll","payroll");

		}
		catch(SQLException s)
		{
			s.printStackTrace();
			System.out.println(s);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
